import type { ChatMessage as ChatMessageType } from '@/types/chat';

type Props = {
  message: ChatMessageType;
};

function formatTimestamp(ts: number): string {
  const date = new Date(ts);
  return date.toLocaleTimeString(undefined, {
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function ChatMessage({ message }: Props) {
  const isUser = message.sender === 'user';
  const isSystem = message.sender === 'system' || message.type === 'system';
  const isError = message.type === 'error';
  const isRoll = message.type === 'roll';

  // System messages
  if (isSystem) {
    return (
      <div className="flex justify-center my-2">
        <div className="text-xs theme-text-muted italic px-3 py-1 rounded-full theme-bg-secondary">
          {message.content}
        </div>
      </div>
    );
  }

  // Error messages
  if (isError) {
    return (
      <div className="flex justify-center my-2">
        <div className="text-xs text-red-400 px-3 py-1 rounded-md bg-red-950/30 border border-red-800/50">
          {message.content}
        </div>
      </div>
    );
  }

  // Roll result
  if (isRoll && message.metadata?.rollResult) {
    const roll = message.metadata.rollResult;
    const isCrit = roll.criticalHit;
    const isFail = roll.criticalFail;

    return (
      <div className={`flex ${isUser ? 'justify-end' : 'justify-start'} my-2`}>
        <div
          className={`max-w-[80%] rounded-lg px-3 py-2 ${
            isCrit
              ? 'bg-amber-900/50 border border-amber-500/50'
              : isFail
              ? 'bg-red-900/50 border border-red-500/50'
              : isUser
              ? 'theme-bg-accent/20 border border-[var(--color-accent)]/30'
              : 'theme-bg-secondary border theme-border'
          }`}
        >
          <div className="flex items-center gap-2 mb-1">
            <span className="text-lg">🎲</span>
            <span className="font-mono text-sm theme-text-secondary">
              {roll.formula}
            </span>
          </div>
          <div className="flex items-center gap-2 text-sm">
            <span className="font-mono theme-text-muted">
              [{roll.rolls.join(', ')}]
            </span>
            {roll.modifier !== 0 && (
              <span className="theme-text-muted">
                {roll.modifier >= 0 ? '+' : ''}{roll.modifier}
              </span>
            )}
            <span className="theme-text-muted">=</span>
            <span
              className={`font-bold text-lg ${
                isCrit
                  ? 'text-amber-400'
                  : isFail
                  ? 'text-red-400'
                  : 'theme-text'
              }`}
            >
              {roll.total}
            </span>
          </div>
          {(isCrit || isFail) && (
            <div
              className={`text-xs mt-1 font-semibold ${
                isCrit ? 'text-amber-400' : 'text-red-400'
              }`}
            >
              {isCrit ? 'Critical Hit!' : 'Critical Fail!'}
            </div>
          )}
          <div className="text-xs theme-text-muted mt-1">
            {formatTimestamp(message.timestamp)}
          </div>
        </div>
      </div>
    );
  }

  // LLM response
  if (message.type === 'llm-response') {
    return (
      <div className="flex justify-start my-2">
        <div className="max-w-[85%] rounded-lg px-3 py-2 theme-bg-secondary border theme-border">
          <div className="flex items-center gap-2 mb-1">
            <span className="text-sm">🤖</span>
            <span className="text-xs theme-text-secondary font-medium">
              {message.metadata?.model || 'AI Assistant'}
            </span>
          </div>
          <div className="text-sm theme-text whitespace-pre-wrap">
            {message.content}
          </div>
          <div className="flex items-center gap-2 mt-2 text-xs theme-text-muted">
            <span>{formatTimestamp(message.timestamp)}</span>
            {message.metadata?.tokensUsed && (
              <span className="theme-text-secondary">
                {message.metadata.tokensUsed} tokens
              </span>
            )}
          </div>
        </div>
      </div>
    );
  }

  // Regular text message
  return (
    <div className={`flex ${isUser ? 'justify-end' : 'justify-start'} my-2`}>
      <div
        className={`max-w-[80%] rounded-lg px-3 py-2 ${
          isUser
            ? 'theme-bg-accent/20 border border-[var(--color-accent)]/30'
            : 'theme-bg-secondary border theme-border'
        }`}
      >
        {message.senderName && !isUser && (
          <div className="text-xs font-medium theme-text-secondary mb-1">
            {message.senderName}
          </div>
        )}
        <div className="text-sm theme-text whitespace-pre-wrap">
          {message.content}
        </div>
        <div className="text-xs theme-text-muted mt-1">
          {formatTimestamp(message.timestamp)}
        </div>
      </div>
    </div>
  );
}
