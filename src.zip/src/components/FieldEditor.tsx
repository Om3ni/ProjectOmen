import { useMemo } from 'react';

import type { SchemaColumn } from '@/models/schema';

type Props = {
  column: SchemaColumn;
  value: unknown;
  onChange: (next: unknown) => void;
  label?: string;
  tooltip?: string;
  appearance?: 'dark' | 'light';
  onFocus?: () => void;
  disabled?: boolean;
};

function isBoolTf(column: SchemaColumn): boolean {
  return String(column.type).toLowerCase() === 'bool_tf';
}

function toBool(value: unknown): boolean {
  if (value === true) return true;
  if (value === false) return false;
  const s = String(value ?? '').trim().toLowerCase();
  if (s === 't') return true;
  if (s === 'f') return false;
  const n = Number(value);
  if (Number.isFinite(n)) return n !== 0;
  return false;
}

function isNumeric(column: SchemaColumn): boolean {
  const t = String(column.type).toLowerCase();
  return t === 'int' || t === 'number' || t === 'int_or_float';
}

export default function FieldEditor({ column, value, onChange, label, tooltip, appearance = 'dark', onFocus, disabled }: Props) {
  const isDark = appearance === 'dark';
  const baseInput = isDark
    ? 'w-full rounded-md border border-slate-700 bg-slate-950/40 px-3 py-2 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-slate-500/40'
    : 'w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-slate-300/60';

  const labelText = label ?? column.name;

  const enumEntries = useMemo(() => {
    const e = column.enum;
    if (!e || typeof e !== 'object') return [];
    return Object.entries(e);
  }, [column.enum]);

  return (
    <div className="flex flex-col gap-1">
      <div className="flex items-end justify-between gap-3">
        <div className={isDark ? 'text-xs font-semibold text-slate-200' : 'text-xs font-semibold text-slate-700'}>
          {labelText}
        </div>
      </div>
      {tooltip ? (
        <div className={isDark ? 'text-[10px] uppercase tracking-wide text-slate-500' : 'text-[10px] text-slate-500'}>
          {tooltip}
        </div>
      ) : null}

      {String(column.type).toLowerCase() === 'literal' || column.const !== undefined ? (
        <input className={baseInput} disabled value={String(column.const ?? value ?? '')} />
      ) : isBoolTf(column) ? (
        (() => {
          const checked = toBool(value);
          return (
        <label className={`flex items-center gap-2 ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}>
          <input
            type="checkbox"
            className="h-4 w-4"
            checked={checked}
            disabled={disabled}
            onChange={(e) => onChange(e.target.checked ? 't' : 'f')}
          />
        </label>
          );
        })()
      ) : enumEntries.length > 0 ? (
        <select
          className={baseInput}
          value={value === undefined || value === null ? '' : String(value)}
          onChange={(e) => onChange(e.target.value)}
          onFocus={onFocus}
        >
          <option value="">Select {labelText}…</option>
          {enumEntries.map(([k, v]) => (
            <option key={k} value={k}>
              {k} – {v}
            </option>
          ))}
        </select>
      ) : isNumeric(column) ? (
        <input
          className={baseInput}
          type="number"
          placeholder={labelText}
          value={value === undefined || value === null ? '' : String(value)}
          onFocus={onFocus}
          onChange={(e) => {
            const raw = e.target.value;
            if (raw === '') {
              onChange('');
              return;
            }
            const num = Number(raw);
            onChange(Number.isFinite(num) ? num : raw);
          }}
        />
      ) : (
        <input
          className={baseInput}
          placeholder={labelText}
          value={value === undefined || value === null ? '' : String(value)}
          onFocus={onFocus}
          onChange={(e) => onChange(e.target.value)}
        />
      )}
    </div>
  );
}
