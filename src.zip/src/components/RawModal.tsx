import { useMemo, useState } from 'react';

import type { RprCategory } from '@/models/schema';
import { CATEGORY_VIEWS } from '@/hooks/useEditorState';
import { useRawGridState } from '@/hooks/useRawGridState';
import { useGridSelection, type CellCoord } from '@/hooks/useGridSelection';
import { useRawGridLayout } from '@/hooks/useRawGridLayout';
import { sequenceIds } from '@/utils/rprSequence';

import { ExpandedCellEditor } from '@/components/raw/ExpandedCellEditor';
import { RawToolbar } from '@/components/raw/RawToolbar';
import { RawPastePanel } from '@/components/raw/RawPastePanel';
import { RawFindReplaceBar } from '@/components/raw/RawFindReplaceBar';
import { RawGrid } from '@/components/raw/RawGrid';

type Props = {
  mode: 'all' | 'selection';
  category: RprCategory;
  initialText: string;
  onApplySelection: (text: string, category: RprCategory) => void;
  onApplyAll: (text: string) => void;
  onExportSelection: (cat: RprCategory) => string;
  onExportAll: () => string;
  onClose: () => void;
  /** When true, renders as full-page component (no modal overlay) */
  isChildWindow?: boolean;
};

export default function RawModal({
  mode: initialMode,
  category: initialCategory,
  initialText,
  onApplySelection,
  onApplyAll,
  onExportSelection,
  onExportAll,
  onClose,
  isChildWindow = false,
}: Props) {
  const [localError, setLocalError] = useState<string | null>(null);

  const { rawMode, rows, setRows, rawCategory, setRawCategory, rawText, refreshFromCategory, importFromText } =
    useRawGridState({ initialText, initialCategory, mode: initialMode });

  const {
    selectedCells,
    focusCell,
    setFocusCell,
    isDragging,
    clearSelection,
    updateCell,
    bulkUpdateCells,
    handleCellMouseDown,
    handleCellMouseEnter,
    selectRow,
    selectCol,
    isSel,
    isFoc,
  } = useGridSelection({ rows, setRows });

  // Expand modal for long content
  const [expandCell, setExpandCell] = useState<CellCoord | null>(null);

  // Find/Replace
  const [findText, setFindText] = useState('');
  const [replaceText, setReplaceText] = useState('');

  // Paste raw - start open if no initial data
  const [showPaste, setShowPaste] = useState(!initialText.trim());
  const [pasteText, setPasteText] = useState('');


  const {
    getColWidth,
    handleResizeStart,
    resizingCol,
    ROW_NUM_WIDTH,
    containerRef,
    setScrollTop,
    ROW_HEIGHT,
    visibleRange,
    getSectionMaxCols,
  } = useRawGridLayout({ rows });

  const { startRow, endRow } = visibleRange;
  const visibleRows = useMemo(() => rows.slice(startRow, endRow), [rows, startRow, endRow]);

  // Track token groups for visual styling
  const getRowToken = (rowIdx: number) => rows[rowIdx]?.[0] ?? '';
  const isNewGroup = (rowIdx: number) => rowIdx === 0 || getRowToken(rowIdx) !== getRowToken(rowIdx - 1);
  
  // Child tokens get indented styling
  const childTokens = new Set([
    'SpellReqDef', 'SpellTargetCond', 'SpellEffect',
    'RuneCond', 'RuneEffect', 'PerkEffect', 'StatusAction',
    'MutatorAction', 'MutatorCondition',
  ]);
  const isChildRow = (rowIdx: number) => childTokens.has(getRowToken(rowIdx));

  const handleApplySelection = () => {
    try {
      setLocalError(null);
      onApplySelection(rawText, rawCategory);
      onClose();
    } catch (e) {
      setLocalError(e instanceof Error ? e.message : String(e));
    }
  };

  const handleApplyAll = () => {
    try {
      setLocalError(null);
      onApplyAll(rawText);
      onClose();
    } catch (e) {
      setLocalError(e instanceof Error ? e.message : String(e));
    }
  };

  const refreshFromAll = () => {
    importFromText(onExportAll());
    clearSelection();
  };

  const handlePasteApply = () => {
    importFromText(pasteText);
    setPasteText('');
    setShowPaste(false);
    clearSelection();
  };

  // Find/Replace
  const handleFindReplace = () => {
    if (!findText) return;
    const inSel = selectedCells.size > 0;
    setRows((prev) => {
      let done = false;
      return prev.map((r, ri) =>
        r.map((c, ci) => {
          if (done) return c;
          if (inSel && !selectedCells.has(`${ri}:${ci}`)) return c;
          if (c.includes(findText)) {
            done = true;
            return c.replace(findText, replaceText);
          }
          return c;
        }),
      );
    });
  };

  const handleFindReplaceAll = () => {
    if (!findText) return;
    const inSel = selectedCells.size > 0;
    setRows((prev) =>
      prev.map((r, ri) =>
        r.map((c, ci) => {
          if (inSel && !selectedCells.has(`${ri}:${ci}`)) return c;
          return c.split(findText).join(replaceText);
        }),
      ),
    );
  };

  const handleSequence = () => {
    setRows((prev) => sequenceIds(prev));
  };

  // Expand modal
  const expandValue = expandCell ? (rows[expandCell.row]?.[expandCell.col] ?? '') : '';

  // When in child window mode, render full-page without modal overlay
  const outerClasses = isChildWindow
    ? 'h-full flex flex-col bg-slate-950 overflow-hidden'
    : 'fixed inset-0 z-50 flex items-start justify-center bg-black/60 p-4 overflow-auto';

  const innerClasses = isChildWindow
    ? 'flex-1 flex flex-col min-h-0 p-4'
    : 'w-full max-w-[95vw] rounded-lg border border-slate-800 bg-slate-950 p-4 my-4';

  return (
    <div className={outerClasses}>
      <ExpandedCellEditor
        cell={expandCell}
        value={expandValue}
        onUpdate={updateCell}
        onClose={() => setExpandCell(null)}
      />

      <div
        className={innerClasses}
        onClick={(e) => e.stopPropagation()}
        onMouseDown={(e) => { if (e.target === e.currentTarget) clearSelection(); }}
      >
        <RawToolbar
          rawMode={rawMode}
          rawCategory={rawCategory}
          categoryViews={CATEGORY_VIEWS}
          onChangeCategory={(next) => {
            setRawCategory(next);
            refreshFromCategory(next, onExportSelection(next));
          }}
          onLoadGrouped={() => {
            if (rawMode === 'selection') {
              refreshFromCategory(rawCategory, onExportSelection(rawCategory));
            } else {
              refreshFromAll();
            }
          }}
          onApply={() => {
            if (rawMode === 'selection') {
              handleApplySelection();
            } else {
              handleApplyAll();
            }
          }}
          showPaste={showPaste}
          onTogglePaste={() => setShowPaste((p) => !p)}
          onCopy={() => navigator.clipboard?.writeText(rawText)}
          onClose={onClose}
        />

        {localError && (
          <div className="mt-4 rounded-md border border-red-800/60 bg-red-950/40 p-3 text-sm text-red-200">
            {localError}
          </div>
        )}

        <RawPastePanel
          show={showPaste}
          autoFocus={!initialText.trim()}
          pasteText={pasteText}
          onChangePasteText={setPasteText}
          onLoad={handlePasteApply}
          onCancel={() => setShowPaste(false)}
        />

        <RawFindReplaceBar
          selectedCount={selectedCells.size}
          findText={findText}
          replaceText={replaceText}
          onChangeFindText={setFindText}
          onChangeReplaceText={setReplaceText}
          onReplace={handleFindReplace}
          onReplaceAll={handleFindReplaceAll}
          onSequenceIds={handleSequence}
          onClearSelection={clearSelection}
        />

        <RawGrid
          isChildWindow={isChildWindow}
          rows={rows}
          visibleRows={visibleRows}
          startRow={startRow}
          endRow={endRow}
          rowHeight={ROW_HEIGHT}
          rowNumWidth={ROW_NUM_WIDTH}
          containerRef={containerRef}
          onScrollTopChange={setScrollTop}
          onClearSelection={clearSelection}
          getSectionMaxCols={getSectionMaxCols}
          getColWidth={getColWidth}
          onResizeStart={handleResizeStart}
          isNewGroup={isNewGroup}
          isChildRow={isChildRow}
          resizingCol={resizingCol}
          onSelectCol={selectCol}
          onSelectRow={selectRow}
          isSel={isSel}
          isFoc={isFoc}
          focusCell={focusCell}
          selectedCells={selectedCells}
          onCellMouseDown={handleCellMouseDown}
          onCellMouseEnter={handleCellMouseEnter}
          onExpandCell={(coord) => setExpandCell(coord)}
          onUpdateCell={updateCell}
          onBulkUpdateCells={bulkUpdateCells}
          onFocusCell={setFocusCell}
          isDragging={isDragging}
        />
      </div>
    </div>
  );
}
