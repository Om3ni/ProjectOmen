import { useMemo, useState } from 'react';

import { inferLabel } from '@/hooks/useEditorState';

type Props = {
  rows: Array<Record<string, unknown>>;
  selectedIndex: number;
  onSelect: (index: number) => void;
  title?: string;
  enableFilter?: boolean;
  filterPlaceholder?: string;
  groupBy?: string;
};

function str(v: unknown): string {
  return v === undefined || v === null ? '' : String(v);
}

export default function RecordListSidebar({
  rows,
  selectedIndex,
  onSelect,
  title = 'Records',
  enableFilter = false,
  filterPlaceholder = 'Filter…',
  groupBy,
}: Props) {
  const [query, setQuery] = useState('');

  const items = useMemo(() => {
    const q = query.trim().toLowerCase();
    const base = rows.map((row, index) => ({ row, index }));
    if (!q) return base;
    return base.filter(({ row }) => {
      const label = inferLabel(row).toLowerCase();
      const id = str(row.ID ?? row['Node ID']).toLowerCase();
      const cat = groupBy ? str(row[groupBy]).toLowerCase() : '';
      return label.includes(q) || id.includes(q) || (cat && cat.includes(q));
    });
  }, [rows, query, groupBy]);

  const grouped = useMemo(() => {
    if (!groupBy) return null;
    const by = new Map<string, Array<{ row: Record<string, unknown>; index: number }>>();
    for (const it of items) {
      const key = str(it.row[groupBy]).trim() || 'Uncategorized';
      const arr = by.get(key) ?? [];
      arr.push(it);
      by.set(key, arr);
    }
    const groups = Array.from(by.entries()).sort(([a], [b]) => a.localeCompare(b));
    for (const [, arr] of groups) {
      arr.sort((x, y) => inferLabel(x.row).localeCompare(inferLabel(y.row)));
    }
    return groups;
  }, [items, groupBy]);

  return (
    <section className="rounded-lg border border-slate-800 bg-slate-900/20 flex flex-col overflow-hidden">
      <div className="border-b border-slate-800 px-3 py-3">
        <div className="text-xs font-semibold uppercase tracking-wide text-slate-400">{title}</div>
        <div className="mt-1 text-xs text-slate-400">
          Showing {items.length} / {rows.length} · Selected {rows.length ? selectedIndex + 1 : 0}
        </div>
        {enableFilter ? (
          <input
            className="mt-2 w-full rounded-md border border-slate-800 bg-slate-950/40 px-2 py-1.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-slate-500/40"
            value={query}
            placeholder={filterPlaceholder}
            onChange={(e) => setQuery(e.target.value)}
          />
        ) : null}
      </div>
      <div className="flex-1 min-h-0 overflow-auto p-2">
        {rows.length === 0 ? (
          <div className="p-2 text-sm text-slate-400">No rows</div>
        ) : (
          <div className="flex flex-col gap-1">
            {grouped ? (
              grouped.map(([groupName, groupItems]) => (
                <div key={groupName} className="mt-2 first:mt-0">
                  <div className="px-2 py-1 text-[10px] font-semibold uppercase tracking-wide text-slate-500">
                    ===== {groupName} =====
                  </div>
                  <div className="flex flex-col gap-1">
                    {groupItems.map(({ row, index }) => {
                      const isActive = index === selectedIndex;
                      const id = row.ID ?? row['Node ID'] ?? '';
                      return (
                        <button
                          key={`${index}-${String(id)}`}
                          type="button"
                          onClick={() => onSelect(index)}
                          className={
                            isActive
                              ? 'rounded-md bg-slate-200 px-2 py-2 text-left text-sm font-medium text-slate-900'
                              : 'rounded-md border border-slate-800 bg-slate-950/40 px-2 py-2 text-left text-sm text-slate-200 hover:bg-slate-900/60'
                          }
                        >
                          <div className="truncate">{inferLabel(row)}</div>
                          <div className={isActive ? 'text-[10px] text-slate-700' : 'text-[10px] text-slate-500'}>
                            {String(id)}
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))
            ) : (
              items.map(({ row, index }) => {
                const isActive = index === selectedIndex;
                const id = row.ID ?? row['Node ID'] ?? '';
                return (
                  <button
                    key={`${index}-${String(id)}`}
                    type="button"
                    onClick={() => onSelect(index)}
                    className={
                      isActive
                        ? 'rounded-md bg-slate-200 px-2 py-2 text-left text-sm font-medium text-slate-900'
                        : 'rounded-md border border-slate-800 bg-slate-950/40 px-2 py-2 text-left text-sm text-slate-200 hover:bg-slate-900/60'
                    }
                  >
                    <div className="truncate">{inferLabel(row)}</div>
                    <div className={isActive ? 'text-[10px] text-slate-700' : 'text-[10px] text-slate-500'}>
                      {String(id)}
                    </div>
                  </button>
                );
              })
            )}
          </div>
        )}
      </div>
    </section>
  );
}
