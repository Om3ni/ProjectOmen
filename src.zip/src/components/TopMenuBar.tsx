import { useState } from 'react';
import type { RefObject } from 'react';

import type { RprCategory, SchemaData, SchemaStructure } from '@/models/schema';
import { getAdapter } from '@/services/PlatformAdapter';

type Props = {
  schema: SchemaStructure | null;
  data: SchemaData | null;
  schemaVersion: string | undefined;
  tooltips: Record<string, string> | undefined;
  activeCategory: RprCategory;
  activeTable: string;
  filteredRowsCount: number;
  fileInputRef: RefObject<HTMLInputElement | null>;
  onNewFile: () => void;
  onLoadFile: () => void;
  onLoadFileSelected: (file: File | null) => void;
  onOpenRawAll: () => void;
  onOpenRawForCategory: (cat: RprCategory) => void;
  onOpenCharacterSheet: () => void;
  onError: (msg: string) => void;
};

export default function TopMenuBar({
  schema,
  data,
  schemaVersion,
  tooltips,
  activeCategory,
  activeTable,
  filteredRowsCount,
  fileInputRef,
  onNewFile,
  onLoadFile,
  onLoadFileSelected,
  onOpenRawAll,
  onOpenRawForCategory,
  onOpenCharacterSheet,
  onError,
}: Props) {
  const [openMenu, setOpenMenu] = useState<'file' | 'edit' | null>(null);

  const downloadSchemaData = async (override?: { data: SchemaData }) => {
    if (!data && !override) return;
    const payload = {
      schemaVersion: schemaVersion ?? schema?.version ?? '',
      data: override?.data ?? data!,
      tooltips: tooltips ?? {},
    };
    try {
      await getAdapter().writeFile(
        'schema-data.json',
        JSON.stringify(payload, null, 2) + '\n',
        'application/json;charset=utf-8',
      );
    } catch (e) {
      onError(e instanceof Error ? e.message : String(e));
    }
  };

  const exportPreserveIds = async () => {
    if (!data) return;
    await downloadSchemaData({ data });
  };

  return (
    <header
      className="flex-shrink-0 border-b border-slate-800 bg-slate-950 relative z-40"
      onClick={() => {
        if (openMenu) setOpenMenu(null);
      }}
    >
      <div className="mx-auto max-w-7xl px-4 py-4">
        <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <h1 className="text-lg font-semibold">RPR Data Editor</h1>
            <p className="text-xs text-slate-400">
              Schema: {schema?.version ?? '…'} · Table: {activeTable} · Rows: {filteredRowsCount}
            </p>

            <div className="mt-2 flex gap-3 text-sm">
              <div className="relative" onClick={(e) => e.stopPropagation()}>
                <button
                  type="button"
                  className="rounded-md border border-slate-800 bg-slate-950/40 px-3 py-1.5 text-sm text-slate-200 hover:bg-slate-900/60"
                  onClick={() => setOpenMenu((m) => (m === 'file' ? null : 'file'))}
                >
                  File ▾
                </button>
                {openMenu === 'file' ? (
                  <div className="absolute left-0 z-50 mt-2 w-56 rounded-md border border-slate-800 bg-slate-950 p-1 shadow-xl">
                    <button
                      type="button"
                      className="w-full rounded px-2 py-2 text-left text-sm hover:bg-slate-900/60"
                      onClick={() => {
                        setOpenMenu(null);
                        onNewFile();
                      }}
                    >
                      New File
                    </button>
                    <button
                      type="button"
                      className="w-full rounded px-2 py-2 text-left text-sm hover:bg-slate-900/60"
                      onClick={() => {
                        setOpenMenu(null);
                        onLoadFile();
                      }}
                    >
                      Load File (import…)
                    </button>
                    <div className="my-1 border-t border-slate-800" />
                    <button
                      type="button"
                      className="w-full rounded px-2 py-2 text-left text-sm hover:bg-slate-900/60"
                      onClick={() => {
                        setOpenMenu(null);
                        exportPreserveIds();
                      }}
                    >
                      Save File (export)
                    </button>
                  </div>
                ) : null}
              </div>

              <div className="relative" onClick={(e) => e.stopPropagation()}>
                <button
                  type="button"
                  className="rounded-md border border-slate-800 bg-slate-950/40 px-3 py-1.5 text-sm text-slate-200 hover:bg-slate-900/60"
                  onClick={() => setOpenMenu((m) => (m === 'edit' ? null : 'edit'))}
                >
                  Edit ▾
                </button>
                {openMenu === 'edit' ? (
                  <div className="absolute left-0 z-50 mt-2 w-64 rounded-md border border-slate-800 bg-slate-950 p-1 shadow-xl">
                    <button
                      type="button"
                      className="w-full rounded px-2 py-2 text-left text-sm hover:bg-slate-900/60"
                      onClick={() => {
                        setOpenMenu(null);
                        onOpenRawAll();
                      }}
                    >
                      Import from Raw…
                    </button>
                    <button
                      type="button"
                      className="w-full rounded px-2 py-2 text-left text-sm hover:bg-slate-900/60"
                      onClick={() => {
                        setOpenMenu(null);
                        onOpenRawForCategory(activeCategory);
                      }}
                    >
                      Select Raw Category…
                    </button>
                    <div className="my-1 border-t border-slate-800" />

                    <button
                      type="button"
                      className="w-full rounded px-2 py-2 text-left text-sm hover:bg-slate-900/60"
                      onClick={() => {
                        setOpenMenu(null);
                        onOpenCharacterSheet();
                      }}
                    >
                      Character Sheet…
                    </button>
                  </div>
                ) : null}
              </div>
            </div>
          </div>
        </div>
      </div>

      <input
        ref={fileInputRef}
        type="file"
        accept="application/json,text/plain,.json,.txt,.rpr"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0] ?? null;
          e.currentTarget.value = '';
          onLoadFileSelected(file);
        }}
      />
    </header>
  );
}
