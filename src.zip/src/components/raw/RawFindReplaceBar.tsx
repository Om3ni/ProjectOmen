type Props = {
  selectedCount: number;
  findText: string;
  replaceText: string;
  onChangeFindText: (text: string) => void;
  onChangeReplaceText: (text: string) => void;
  onReplace: () => void;
  onReplaceAll: () => void;
  onSequenceIds: () => void;
  onClearSelection: () => void;
};

export function RawFindReplaceBar({
  selectedCount,
  findText,
  replaceText,
  onChangeFindText,
  onChangeReplaceText,
  onReplace,
  onReplaceAll,
  onSequenceIds,
  onClearSelection,
}: Props) {
  return (
    <div className="mt-4 flex flex-wrap items-center gap-2 rounded-md border border-slate-800 bg-slate-900/30 p-2">
      <span className="text-xs text-slate-400">{selectedCount > 0 ? `${selectedCount} cells` : 'All'}</span>
      <input
        type="text"
        className="rounded-md border border-slate-700 bg-slate-950/40 px-2 py-1 text-sm text-slate-100 w-28"
        placeholder="Find..."
        value={findText}
        onChange={(e) => onChangeFindText(e.target.value)}
      />
      <input
        type="text"
        className="rounded-md border border-slate-700 bg-slate-950/40 px-2 py-1 text-sm text-slate-100 w-28"
        placeholder="Replace..."
        value={replaceText}
        onChange={(e) => onChangeReplaceText(e.target.value)}
      />
      <button
        type="button"
        className="rounded-md bg-sky-600 px-2 py-1 text-xs font-medium text-white hover:bg-sky-500"
        onClick={onReplace}
      >
        Replace
      </button>
      <button
        type="button"
        className="rounded-md bg-amber-500 px-2 py-1 text-xs font-medium text-slate-950 hover:bg-amber-400"
        onClick={onReplaceAll}
      >
        Replace All
      </button>
      <button
        type="button"
        className="rounded-md bg-violet-600 px-2 py-1 text-xs font-medium text-white hover:bg-violet-500"
        onClick={onSequenceIds}
        title="Re-sequence Node IDs"
      >
        Sequence IDs
      </button>
      {selectedCount > 0 && (
        <button
          type="button"
          className="rounded-md border border-slate-700 bg-slate-950/40 px-2 py-1 text-xs text-slate-300 hover:bg-slate-900/60"
          onClick={onClearSelection}
        >
          Clear
        </button>
      )}
    </div>
  );
}
