import type { SchemaData, SchemaStructure, TableSchema } from '@/models/schema';

function orderedColumns(schema: TableSchema) {
  return [...(schema.columns ?? [])].sort((a, b) => (a.index ?? 0) - (b.index ?? 0));
}

/**
 * Stringify a cell value, respecting column type for proper formatting.
 * float_or_int and int_or_float types always output with decimal (e.g., 0.0, 1.0)
 */
function stringifyCell(value: unknown, colType?: string): string {
  if (value === undefined || value === null) return '';
  
  const t = (colType ?? '').toLowerCase();
  
  // For float types, ensure decimal format
  if (t === 'float_or_int' || t === 'int_or_float' || t === 'float') {
    const num = Number(value);
    if (Number.isFinite(num)) {
      // If it's a whole number, add .0
      if (Number.isInteger(num)) {
        return `${num}.0`;
      }
      return String(num);
    }
    return String(value);
  }
  
  return String(value);
}

function inferToken(tableName: string, tableSchema: TableSchema): string {
  const cols = orderedColumns(tableSchema);
  const first = cols[0] as unknown;
  if (first && typeof first === 'object' && 'const' in first) {
    const v = (first as { const?: unknown }).const;
    if (typeof v === 'string' && v.trim()) return v;
  }
  return tableName;
}

export function exportSchemaDataToRprText(
  schema: SchemaStructure,
  data: SchemaData,
  options?: {
    includeTables?: Set<string>;
    filterRow?: (tableName: string, row: Record<string, unknown>) => boolean;
  },
): string {
  const includeTables = options?.includeTables;
  const filterRow = options?.filterRow;

  const lines: string[] = [];

  for (const [tableName, tableSchema] of Object.entries(schema.tables ?? {})) {
    if (includeTables && !includeTables.has(tableName)) continue;

    const rows = Array.isArray(data[tableName]) ? (data[tableName] as Array<Record<string, unknown>>) : [];
    if (!rows.length) continue;

    const cols = orderedColumns(tableSchema);
    const token = inferToken(tableName, tableSchema);

    for (const row of rows) {
      if (filterRow && !filterRow(tableName, row)) continue;

      const parts: string[] = [];
      parts.push(token);

      // Token represents the first column when it is a const literal; remaining parts map to the remaining columns.
      // If a table doesn't use a const literal first column, the importer will treat the token as column 0 anyway.
      for (let i = 1; i < cols.length; i += 1) {
        parts.push(stringifyCell(row[cols[i].name], cols[i].type));
      }

      lines.push(parts.join('|'));
    }
  }

  return lines.join('\n').trimEnd();
}

function stripRowPrefix(line: string): string {
  // Allow pasting from the preview format like: "12\tSkillDef|..."
  return line.replace(/^\s*\d+\s*\t/, '').trimEnd();
}

export function rprPreviewWithNumbers(text: string): string {
  const lines = String(text)
    .replace(/\r\n/g, '\n')
    .replace(/\r/g, '\n')
    .split('\n')
    .map((l) => l.trimEnd())
    .filter((l) => l.trim().length > 0);

  const numbered = lines.map((l, i) => `${i + 1}\t${l}`);
  return numbered.join('\n').trimEnd();
}

export function stripRprPreviewPrefixes(text: string): string {
  return String(text)
    .replace(/\r\n/g, '\n')
    .replace(/\r/g, '\n')
    .split('\n')
    .map((l) => stripRowPrefix(l.trimEnd()))
    .join('\n')
    .trimEnd();
}
