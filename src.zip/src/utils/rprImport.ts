import type { SchemaData, SchemaStructure, TableSchema } from '@/models/schema';

const DEFAULT_IGNORED = new Set([
  'DiceConfig',
  'DiceRules',
  'Gear',
  'Mechanic',
  'Megascope',
  'MechanicCondition',
]);

function orderedColumns(schema: TableSchema) {
  return [...schema.columns].sort((a, b) => (a.index ?? 0) - (b.index ?? 0));
}

function toTf(value: string): 't' | 'f' {
  const v = value.trim().toLowerCase();
  if (v === 't' || v === 'true' || v === '1' || v === 'yes' || v === 'y') return 't';
  return 'f';
}

function parseNumberMaybe(text: string): number | string {
  const trimmed = text.trim();
  if (trimmed === '') return '';
  const n = Number(trimmed);
  return Number.isFinite(n) ? n : text;
}

function parseCell(raw: string, type: string): unknown {
  const text = raw ?? '';
  const t = type || 'string';

  switch (t) {
    case 'int': {
      const n = Number.parseInt(text, 10);
      return Number.isFinite(n) ? n : 0;
    }
    case 'float':
    case 'float_or_int':
    case 'int_or_float': {
      const n = Number.parseFloat(text);
      return Number.isFinite(n) ? n : 0;
    }
    case 'bool_tf':
      return toTf(text);

    case 'char':
      return text;

    // common schema types we keep as strings
    case 'string':
    case 'string_or_empty':
    case 'string_or_id':
      return text;

    default:
      // Be permissive: many columns in the wider RPR ecosystem are numeric-ish.
      return parseNumberMaybe(text);
  }
}

function buildLiteralToTableMap(schema: SchemaStructure): Map<string, string> {
  const map = new Map<string, string>();

  for (const [tableName, tableSchema] of Object.entries(schema.tables ?? {})) {
    // Allow direct match by table name
    map.set(tableName, tableName);

    const cols = orderedColumns(tableSchema);
    const first = cols[0] as unknown;
    if (first && typeof first === 'object' && 'const' in first) {
      const v = (first as { const?: unknown }).const;
      if (typeof v === 'string') map.set(v, tableName);
    }
  }

  return map;
}

function parseLine(schema: TableSchema, literalToken: string, fields: string[]): Record<string, unknown> {
  const cols = orderedColumns(schema);
  const first = cols[0] as unknown;

  // If first column is a const literal matching the line token, the token is not part of fields.
  const hasConstLiteral =
    !!first &&
    typeof first === 'object' &&
    'const' in first &&
    typeof (first as { const?: unknown }).const === 'string' &&
    String((first as { const?: unknown }).const) === literalToken;

  // Legacy/raw format always begins each line with a table token.
  // When a table does NOT have a const literal as its first column, treat that token as column 0.
  const effectiveFields = hasConstLiteral ? fields : [literalToken, ...fields];
  const startColIndex = hasConstLiteral ? 1 : 0;
  const row: Record<string, unknown> = {};

  for (let colIdx = startColIndex; colIdx < cols.length; colIdx++) {
    const col = cols[colIdx];
    const fieldIdx = colIdx - startColIndex;
    row[col.name] = parseCell(effectiveFields[fieldIdx] ?? '', col.type);
  }

  return row;
}

export function parseRprTextToSchemaData(
  schema: SchemaStructure,
  text: string,
  ignoredTokens: Set<string> = DEFAULT_IGNORED,
): SchemaData {
  const literalMap = buildLiteralToTableMap(schema);
  const next: SchemaData = {};

  // Legacy UX allows pasting as one long line; it inserts newlines before any known token+pipe.
  let normalized = String(text ?? '').trim();
  const newlineCount = (normalized.match(/\r?\n/g) || []).length;
  if (newlineCount < 2) {
    const tokens = Array.from(literalMap.keys())
      .map((t) => t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'))
      .filter((t) => t.length > 0);
    if (tokens.length) {
      const re = new RegExp(`(?!^)\\b(${tokens.join('|')})\\|`, 'g');
      normalized = normalized.replace(re, '\n$1|').trim();
    }
  }

  const lines = normalized
    .replace(/\r\n/g, '\n')
    .replace(/\r/g, '\n')
    .split('\n')
    .map((l) => l.trimEnd())
    .filter((l) => l.trim().length > 0);

  for (const line of lines) {
    const parts = line.split('|');
    const token = parts[0]?.trim();
    if (!token) continue;

    if (ignoredTokens.has(token)) continue;

    const tableName = literalMap.get(token);
    if (!tableName) {
      // Unknown table: ignore
      continue;
    }

    const tableSchema = schema.tables?.[tableName];
    if (!tableSchema) continue;

    const row = parseLine(tableSchema, token, parts.slice(1));

    const arr = Array.isArray(next[tableName]) ? (next[tableName] as Array<Record<string, unknown>>) : [];
    arr.push(row);
    next[tableName] = arr;
  }

  // Auto-create parent records for orphaned children
  autoCreateParentRecords(schema, next);

  // Validate that we actually parsed something
  const totalRows = Object.values(next).reduce((sum, arr) => sum + (Array.isArray(arr) ? arr.length : 0), 0);
  if (totalRows === 0 && lines.length > 0) {
    throw new Error(
      `No valid records found. Make sure the text is in RPR pipe format (e.g., "TableName|field1|field2|..."). ` +
        `Found ${lines.length} line(s) but none matched known tables.`,
    );
  }

  return next;
}

/**
 * Child table → Parent table mapping with their FK and parent ID field
 */
const CHILD_PARENT_MAP: Record<string, { parentTable: string; fk: string; parentIdField: string }> = {
  RuneAction: { parentTable: 'RuneDef', fk: 'RuneID', parentIdField: 'ID' },
  RuneCondition: { parentTable: 'RuneDef', fk: 'RuneID', parentIdField: 'ID' },
  PerkAction: { parentTable: 'PerkDef', fk: 'PerkID', parentIdField: 'ID' },
  StatusAction: { parentTable: 'StatusDef', fk: 'StatusID', parentIdField: 'ID' },
  MutatorAction: { parentTable: 'MutatorDef', fk: 'MutatorID', parentIdField: 'ID' },
  MutatorCondition: { parentTable: 'MutatorDef', fk: 'MutatorID', parentIdField: 'ID' },
  SpellEffect: { parentTable: 'SpellDef', fk: 'SpellID', parentIdField: 'ID' },
  SpellReqDef: { parentTable: 'SpellDef', fk: 'SpellID', parentIdField: 'ID' },
  SpellTargetCond: { parentTable: 'SpellDef', fk: 'SpellID', parentIdField: 'ID' },
};

/**
 * Automatically create parent records for child records that reference non-existent parents.
 */
function autoCreateParentRecords(schema: SchemaStructure, data: SchemaData): void {
  for (const [childTable, mapping] of Object.entries(CHILD_PARENT_MAP)) {
    const childRows = Array.isArray(data[childTable]) ? (data[childTable] as Array<Record<string, unknown>>) : [];
    if (!childRows.length) continue;

    const parentTable = mapping.parentTable;
    const parentSchema = schema.tables?.[parentTable];
    if (!parentSchema) continue;

    const parentRows = Array.isArray(data[parentTable]) ? (data[parentTable] as Array<Record<string, unknown>>) : [];
    const existingParentIds = new Set(parentRows.map((r) => Number(r[mapping.parentIdField])));

    // Find all unique parent IDs referenced by children that don't exist
    const neededParentIds = new Set<number>();
    for (const child of childRows) {
      const parentId = Number(child[mapping.fk]);
      if (Number.isFinite(parentId) && parentId > 0 && !existingParentIds.has(parentId)) {
        neededParentIds.add(parentId);
      }
    }

    // Create placeholder parent records for each missing ID
    if (neededParentIds.size > 0) {
      const newParents: Array<Record<string, unknown>> = [];
      for (const parentId of neededParentIds) {
        const parent = createMinimalParentRecord(parentSchema, mapping.parentIdField, parentId, parentTable);
        newParents.push(parent);
      }
      data[parentTable] = [...parentRows, ...newParents];
    }
  }
}

/**
 * Create a minimal parent record with defaults and the specified ID.
 */
function createMinimalParentRecord(
  schema: TableSchema,
  idField: string,
  idValue: number,
  tableName: string,
): Record<string, unknown> {
  const record: Record<string, unknown> = {};
  const cols = [...schema.columns].sort((a, b) => (a.index ?? 0) - (b.index ?? 0));

  for (const col of cols) {
    if (col.const !== undefined) {
      record[col.name] = col.const;
    } else if (col.default !== undefined) {
      record[col.name] = col.default;
    } else {
      // Provide sensible defaults based on type
      switch (col.type) {
        case 'int':
        case 'float':
        case 'float_or_int':
        case 'int_or_float':
          record[col.name] = 0;
          break;
        case 'bool_tf':
          record[col.name] = 'f';
          break;
        default:
          record[col.name] = '';
      }
    }
  }

  // Set the ID
  record[idField] = idValue;

  // Set a placeholder name
  const singularNames: Record<string, string> = {
    RuneDef: 'Rune',
    PerkDef: 'Perk',
    StatusDef: 'Status',
    MutatorDef: 'Mutator',
    SpellDef: 'Ability',
  };
  const singular = singularNames[tableName] ?? tableName.replace(/Def$/, '');
  if ('Name' in record || schema.columns.some((c) => c.name === 'Name')) {
    record.Name = `${singular} ${idValue}`;
  }

  return record;
}
