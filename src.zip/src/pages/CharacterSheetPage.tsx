import { useEffect, useMemo, useState } from 'react';

import type { SchemaData } from '@/models/schema';
import CharacterSheetModal from '@/components/CharacterSheetModal';

type InitPayload = {
  data: SchemaData;
};

export default function CharacterSheetPage() {
  const [payload, setPayload] = useState<InitPayload | null>(null);

  const isDesktop = useMemo(() => {
    try {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      return typeof window !== 'undefined' && typeof (window as any).electron !== 'undefined';
    } catch {
      return false;
    }
  }, []);

  useEffect(() => {
    if (!isDesktop) return;

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const electron = (window as any).electron as any;

    const unsub = electron?.sheetWindow?.onInit?.((data: any) => {
      setPayload(data as InitPayload);
    });

    (async () => {
      try {
        const existing = await electron?.sheetWindow?.getData?.();
        if (existing && !payload) setPayload(existing as InitPayload);
      } catch {
        // ignore
      }
    })();

    return () => {
      try {
        unsub?.();
      } catch {
        // ignore
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isDesktop]);

  if (!payload?.data) {
    return <div className="h-full w-full bg-slate-950 text-slate-200 p-4">Loading character sheet…</div>;
  }

  return (
    <div className="h-full w-full overflow-hidden bg-slate-950 text-slate-100">
      <CharacterSheetModal
        data={payload.data}
        isChildWindow={true}
        onClose={() => {
          try {
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            const electron = (window as any).electron as any;
            electron?.sheetWindow?.close?.();
          } catch {
            window.close();
          }
        }}
      />
    </div>
  );
}
