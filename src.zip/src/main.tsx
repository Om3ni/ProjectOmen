import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.tsx'

// Initialize platform adapter before rendering
import { setAdapter } from '@/services/PlatformAdapter'
import { BrowserAdapter } from '@/services/BrowserAdapter'
import { ElectronAdapter } from '@/services/ElectronAdapter'

// Prefer Electron adapter when running in the desktop shell.
const isElectron = typeof window !== 'undefined' && typeof (window as any).electron !== 'undefined'
setAdapter(isElectron ? new ElectronAdapter() : new BrowserAdapter())

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
)
